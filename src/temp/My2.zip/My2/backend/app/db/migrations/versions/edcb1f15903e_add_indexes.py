"""Add performance indexes for bookings and halls

Revision ID: add_indexes_001
Revises: 
Create Date: 2025-02-15
"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'add_indexes_001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # Booking related indexes
    op.create_index(
        'idx_booking_hall_date',
        'bookings',
        ['hall_id', 'start_date', 'end_date']
    )

    op.create_index(
        'idx_booking_times',
        'bookings',
        ['start_time', 'end_time']
    )

    op.create_index(
        'idx_booking_status',
        'bookings',
        ['status']
    )

    # Halls related indexes
    op.create_index(
        'idx_halls_location',
        'halls',
        ['location']
    )

    op.create_index(
        'idx_halls_capacity',
        'halls',
        ['capacity']
    )


def downgrade():
    # Drop indexes
    op.drop_index('idx_booking_hall_date', table_name='bookings')
    op.drop_index('idx_booking_times', table_name='bookings')
    op.drop_index('idx_booking_status', table_name='bookings')

    op.drop_index('idx_halls_location', table_name='halls')
    op.drop_index('idx_halls_capacity', table_name='halls')
