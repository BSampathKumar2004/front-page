"""merge heads

Revision ID: 82b34172d4b6
Revises: 537566340360, fix_booking_daterange
Create Date: 2025-12-02 16:06:45.403847

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '82b34172d4b6'
down_revision: Union[str, Sequence[str], None] = ('537566340360', 'fix_booking_daterange')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
