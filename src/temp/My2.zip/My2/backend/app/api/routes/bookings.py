from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from datetime import timedelta, date, time
from app.db.session import SessionLocal
from app.models.booking import Booking
from app.models.user import User
from app.models.admin import Admin
from app.models.hall import Hall
from app.schemas.booking import BookingCreate, BookingOut
from app.core.auth_utils import decode_token
from app.utils.razorpay_client import razorpay_client
from app.core.logging_config import get_logger

router = APIRouter(prefix="/bookings", tags=["Bookings"])
logger = get_logger()


# ---------------- DB SESSION ----------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------- ROLE + USER/ADMIN RESOLUTION ----------------
def resolve_token_user(token: str, db: Session):
    payload = decode_token(token)

    email = payload["sub"]
    role = payload["role"]

    if role == "admin":
        admin = db.query(Admin).filter(Admin.email == email).first()
        if not admin:
            raise HTTPException(status_code=404, detail="Admin not found")
        return admin, "admin"

    if role == "user":
        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        return user, "user"

    raise HTTPException(status_code=401, detail="Invalid role")


# =====================================================================
#                  PURE SQL OVERLAP CHECK FUNCTION (FASTEST)
# =====================================================================
def has_conflict(db: Session, hall_id: int, start_date, end_date, start_time, end_time):
    """
    PURE SQL overlap detection.
    Handles single-day & multi-day bookings correctly.
    """

    conflict = db.query(Booking.id).filter(
        Booking.hall_id == hall_id,
        Booking.status == "booked",

        # 1. UNIVERSAL DATE RANGE OVERLAP CHECK
        Booking.start_date <= end_date,
        Booking.end_date >= start_date,

        # 2. TIME LOGIC (only applies if both bookings are single-day)
        or_(
            Booking.start_date != Booking.end_date,  # existing multi-day
            start_date != end_date,                  # new multi-day

            # Both single-day → apply time overlap
            and_(
                Booking.start_date == Booking.end_date,
                start_date == end_date,
                Booking.start_time < end_time,
                Booking.end_time > start_time
            )
        )
    ).first()

    return conflict is not None


# =====================================================================
#                       PRICING CALCULATION FUNCTION
# =====================================================================
def calculate_price(hall: Hall, start_date, end_date, start_time, end_time):

    # SAME DAY — HOURLY PRICING
    if start_date == end_date:
        start_hr = start_time.hour + start_time.minute / 60
        end_hr = end_time.hour + end_time.minute / 60
        hours = end_hr - start_hr

        if hours <= 0:
            raise HTTPException(status_code=400, detail="Invalid hours")

        total = hours * hall.price_per_hour

        if start_date.weekday() >= 5:
            total *= hall.weekend_price_multiplier

        return round(total + hall.security_deposit, 2)

    # MULTI-DAY PRICING
    total = 0

    # Day 1 partial
    start_hours = 24 - (start_time.hour + start_time.minute / 60)
    total += start_hours * hall.price_per_hour

    # Middle full days
    full_days = (end_date - start_date).days - 1
    if full_days > 0:
        for d in range(full_days):
            weekday = (start_date + timedelta(days=d + 1)).weekday()
            daily_rate = hall.price_per_day

            if weekday >= 5:
                daily_rate *= hall.weekend_price_multiplier

            total += daily_rate

    # Last day partial
    end_hours = end_time.hour + end_time.minute / 60
    total += end_hours * hall.price_per_hour

    # Weekend check
    if end_date.weekday() >= 5:
        total *= hall.weekend_price_multiplier

    return round(total + hall.security_deposit, 2)


# =====================================================================
#                            CREATE BOOKING
# =====================================================================
@router.post("/", response_model=dict)
def create_booking(data: BookingCreate, token: str, db: Session = Depends(get_db)):

    user, role = resolve_token_user(token, db)

    if role != "user":
        raise HTTPException(status_code=403, detail="Only users can book halls")

    hall = db.query(Hall).filter(Hall.id == data.hall_id, Hall.deleted == False).first()
    if not hall:
        raise HTTPException(status_code=404, detail="Hall not found")

    # Validations
    if data.end_date < data.start_date:
        raise HTTPException(status_code=400, detail="End date cannot be before start date")

    if data.start_date == data.end_date and data.end_time <= data.start_time:
        raise HTTPException(status_code=400, detail="End time must be after start time")

    # Check conflict
    if has_conflict(db, data.hall_id, data.start_date, data.end_date, data.start_time, data.end_time):
        logger.bind(log_type="booking").info(
            f"Conflict: Hall {data.hall_id} for {data.start_date} {data.start_time} → {data.end_date} {data.end_time}"
        )
        raise HTTPException(status_code=400, detail="Hall already booked for this time range")

    # Calculate price
    total_price = calculate_price(hall, data.start_date, data.end_date, data.start_time, data.end_time)

    # Create booking object
    booking = Booking(
        user_id=user.id,
        hall_id=data.hall_id,
        start_date=data.start_date,
        end_date=data.end_date,
        start_time=data.start_time,
        end_time=data.end_time,
        status="booked",
        total_price=total_price,
        payment_mode=data.payment_mode,
        payment_status="pending",
    )

    db.add(booking)
    db.commit()
    db.refresh(booking)

    logger.bind(log_type="booking").info(
        f"Booking Created: User={user.email} Hall={booking.hall_id} "
        f"{booking.start_date}→{booking.end_date}"
    )

    # ONLINE PAYMENT FLOW
    if data.payment_mode == "online":
        rp_order = razorpay_client.order.create({
            "amount": int(total_price * 100),
            "currency": "INR",
            "receipt": f"booking_{booking.id}"
        })

        booking.razorpay_order_id = rp_order["id"]
        db.commit()

        return {
            "message": "Proceed with online payment",
            "booking_id": booking.id,
            "total_price": total_price,
            "razorpay_order_id": rp_order["id"],
            "razorpay_key_id": razorpay_client.auth[0],
        }

    # PAY AT VENUE
    return {
        "message": "Booking created. Pay at venue.",
        "booking_id": booking.id,
        "total_price": total_price,
        "payment_status": "pending",
    }


# =====================================================================
#                        VERIFY RAZORPAY PAYMENT
# =====================================================================
@router.post("/verify-payment")
def verify_payment(
    booking_id: int,
    razorpay_payment_id: str,
    razorpay_order_id: str,
    razorpay_signature: str,
    db: Session = Depends(get_db),
):

    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")

    # Validate signature
    try:
        razorpay_client.utility.verify_payment_signature({
            "razorpay_order_id": razorpay_order_id,
            "razorpay_payment_id": razorpay_payment_id,
            "razorpay_signature": razorpay_signature,
        })
    except Exception:
        booking.payment_status = "failed"
        db.commit()

        logger.bind(log_type="payment").error(
            f"Payment FAILED | Booking={booking_id} | Payment={razorpay_payment_id}"
        )

        raise HTTPException(status_code=400, detail="Invalid payment signature")

    booking.payment_status = "success"
    booking.razorpay_payment_id = razorpay_payment_id
    booking.razorpay_signature = razorpay_signature
    db.commit()

    logger.bind(log_type="payment").info(
        f"Payment SUCCESS | Booking={booking_id} | Payment={razorpay_payment_id}"
    )

    return {"message": "Payment verified successfully"}


# =====================================================================
#                          MY BOOKINGS
# =====================================================================
@router.get("/my", response_model=list[BookingOut])
def my_bookings(token: str, db: Session = Depends(get_db)):
    user, role = resolve_token_user(token, db)

    bookings = db.query(Booking).filter(Booking.user_id == user.id).all()

    return [
        BookingOut(
            id=b.id,
            hall_id=b.hall_id,
            start_date=b.start_date,
            end_date=b.end_date,
            start_time=b.start_time,
            end_time=b.end_time,
            status=b.status,
            total_price=b.total_price,
            booked_by_name=user.name,
            booked_by_email=user.email,
        )
        for b in bookings
    ]


# =====================================================================
#                        CANCEL BOOKING
# =====================================================================
@router.delete("/{booking_id}")
def cancel_booking(booking_id: int, token: str, db: Session = Depends(get_db)):
    user, role = resolve_token_user(token, db)

    booking = db.query(Booking).filter(
        Booking.id == booking_id,
        Booking.user_id == user.id,
    ).first()

    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")

    booking.status = "cancelled"
    db.commit()

    logger.bind(log_type="booking").info(
        f"Booking Canceled | BookingID={booking_id} | User={user.email}"
    )

    return {"message": "Booking cancelled successfully"}


# =====================================================================
#                ADMIN — HALL BOOKINGS LIST
# =====================================================================
@router.get("/admin/hall/{hall_id}", response_model=list[
    BookingOut])
def hall_bookings_admin(hall_id: int, token: str, db: Session = Depends(get_db)):

    user, role = resolve_token_user(token, db)
    if role != "admin":
        raise HTTPException(status
        )
    bookings = db.query(Booking).filter(Booking.hall_id == hall_id).all()

    return [
        BookingOut(
            id=b.id,
            hall_id=b.hall_id,
            start_date=b.start_date,
            end_date=b.end_date,
            start_time=b.start_time,
            end_time=b.end_time,
            status=b.status,
            total_price=b.total_price,
            booked_by_name=b.user.name,
            booked_by_email=b.user.email,
        )
        for b in bookings
    ]


# =====================================================================
# AVAILABLE DATES (PER MONTH)
# =====================================================================
@router.get("/hall/{hall_id}/available-dates")
def available_dates(hall_id: int, month: str, db: Session = Depends(get_db)):

    try:
        year, month_num = map(int, month.split("-"))
        start_date = date(year, month_num, 1)
        end_date = (
            date(year + month_num // 12, (month_num % 12) + 1, 1)
            - timedelta(days=1)
        )
    except:
        raise HTTPException(status_code=400, detail="Invalid month format (YYYY-MM)")

    bookings = db.query(Booking).filter(
        Booking.hall_id == hall_id,
        Booking.status == "booked",
        Booking.start_date <= end_date,
        Booking.end_date >= start_date,
    ).all()

    booked = set()

    for b in bookings:
        d = max(b.start_date, start_date)
        last = min(b.end_date, end_date)

        while d <= last:
            booked.add(d)
            d += timedelta(days=1)

    all_days = [
        start_date + timedelta(days=i)
        for i in range((end_date - start_date).days + 1)
    ]

    available = [d.isoformat() for d in all_days if d not in booked]

    return {"hall_id": hall_id, "month": month, "available_dates": available}


# =====================================================================
# AVAILABLE TIME SLOTS (PER DATE)
# =====================================================================
@router.get("/hall/{hall_id}/available-slots")
def available_slots(hall_id: int, date_str: str, db: Session = Depends(get_db)):

    try:
        target_date = date.fromisoformat(date_str)
    except:
        raise HTTPException(status_code=400, detail="Invalid date format (YYYY-MM-DD)")

    bookings = db.query(Booking).filter(
        Booking.hall_id == hall_id,
        Booking.status == "booked",
        Booking.start_date <= target_date,
        Booking.end_date >= target_date,
    ).all()

    # NO BOOKINGS → FULL DAY
    if not bookings:
        return {
            "hall_id": hall_id,
            "date": date_str,
            "available_slots": [{"start": "00:00", "end": "23:59"}],
        }

    blocked = []

    for b in bookings:

        # FULL BLOCK (middle day)
        if b.start_date < target_date < b.end_date:
            blocked.append(("00:00", "23:59"))
            continue

        # START DAY
        if target_date == b.start_date and b.start_date != b.end_date:
            blocked.append((b.start_time.strftime("%H:%M"), "23:59"))
            continue

        # END DAY
        if target_date == b.end_date and b.start_date != b.end_date:
            blocked.append(("00:00", b.end_time.strftime("%H:%M")))
            continue

        # SINGLE DAY BOOKING
        if b.start_date == b.end_date == target_date:
            blocked.append(
                (b.start_time.strftime("%H:%M"), b.end_time.strftime("%H:%M"))
            )

    # FULL DAY BLOCKED
    if any(start == "00:00" and end == "23:59" for start, end in blocked):
        return {"hall_id": hall_id, "date": date_str, "available_slots": []}

    blocked.sort()
    merged = []
    current_start, current_end = blocked[0]

    def to_min(t):
        return int(t[:2]) * 60 + int(t[3:])

    for s, e in blocked[1:]:
        if to_min(s) <= to_min(current_end):
            current_end = max(current_end, e)
        else:
            merged.append((current_start, current_end))
            current_start, current_end = s, e

    merged.append((current_start, current_end))

    # Convert block → available
    available = []
    last_end = "00:00"

    for s, e in merged:
        if to_min(s) > to_min(last_end):
            available.append({"start": last_end, "end": s})
        last_end = e

    if last_end != "23:59":
        available.append({"start": last_end, "end": "23:59"})

    return {
        "hall_id": hall_id,
        "date": date_str,
        "available_slots": available,
    }


# =====================================================================
# MULTI-HALL CALENDAR (MONTH VIEW)
# =====================================================================
@router.get("/calendar")
def multi_hall_calendar(month: str, db: Session = Depends(get_db)):

    try:
        year, month_num = map(int, month.split("-"))
        start_date = date(year, month_num, 1)
        end_date = (
            date(year + month_num // 12, (month_num % 12) + 1, 1)
            - timedelta(days=1)
        )
    except:
        raise HTTPException(status_code=400, detail="Invalid month format (YYYY-MM)")

    halls = db.query(Hall).filter(Hall.deleted == False).all()
    hall_booked_map = {h.id: [] for h in halls}

    bookings = db.query(Booking).filter(
        Booking.status == "booked",
        Booking.start_date <= end_date,
        Booking.end_date >= start_date,
    ).all()

    for b in bookings:
        d = max(b.start_date, start_date)
        last = min(b.end_date, end_date)

        while d <= last:
            hall_booked_map[b.hall_id].append(d.isoformat())
            d += timedelta(days=1)

    return {
        "month": month,
        "halls": [
            {
                "hall_id": hid,
                "booked_dates": sorted(list(set(days))),
            }
            for hid, days in hall_booked_map.items()
        ],
    }
